-- ═══════════════════════════════════════════════════════
-- JUST UNIQUE STORIES TRADING PLATFORM — DATABASE SCHEMA
-- Run: psql -U postgres -d justuniquestories_db -f schema.sql
-- ═══════════════════════════════════════════════════════

-- EXTENSIONS
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "citext";

-- ── USERS ──────────────────────────────────────────────
CREATE TABLE users (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email               CITEXT UNIQUE NOT NULL,
  phone               VARCHAR(20) UNIQUE,
  password_hash       VARCHAR(255),
  first_name          VARCHAR(100) NOT NULL,
  last_name           VARCHAR(100) NOT NULL,
  username            VARCHAR(50) UNIQUE,
  country             VARCHAR(100),
  currency            VARCHAR(10) DEFAULT 'USD',
  avatar_url          TEXT,
  role                VARCHAR(20) DEFAULT 'user',  -- user | admin | vip

  -- Auth providers
  google_id           VARCHAR(255) UNIQUE,
  apple_id            VARCHAR(255) UNIQUE,
  provider            VARCHAR(20) DEFAULT 'email', -- email | google | apple

  -- Verification status
  email_verified      BOOLEAN DEFAULT FALSE,
  phone_verified      BOOLEAN DEFAULT FALSE,
  kyc_status          VARCHAR(20) DEFAULT 'none',  -- none | pending | verified | rejected
  liveness_verified   BOOLEAN DEFAULT FALSE,
  two_fa_enabled      BOOLEAN DEFAULT FALSE,
  two_fa_secret       TEXT,

  -- Account status
  status              VARCHAR(20) DEFAULT 'active', -- active | suspended | banned
  trading_mode        VARCHAR(10) DEFAULT 'paper',  -- paper | live

  -- Metadata
  last_login          TIMESTAMPTZ,
  last_ip             INET,
  failed_login_count  INT DEFAULT 0,
  locked_until        TIMESTAMPTZ,
  created_at          TIMESTAMPTZ DEFAULT NOW(),
  updated_at          TIMESTAMPTZ DEFAULT NOW()
);

-- ── WALLETS ────────────────────────────────────────────
CREATE TABLE wallets (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  currency        VARCHAR(10) NOT NULL DEFAULT 'USD',
  balance         DECIMAL(20,8) DEFAULT 0,
  locked_balance  DECIMAL(20,8) DEFAULT 0,  -- funds locked in open trades
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, currency)
);

-- ── TRANSACTIONS ───────────────────────────────────────
CREATE TABLE transactions (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type            VARCHAR(30) NOT NULL,  -- deposit | withdrawal | trade_open | trade_close | fee | bonus
  amount          DECIMAL(20,8) NOT NULL,
  currency        VARCHAR(10) NOT NULL DEFAULT 'USD',
  fee             DECIMAL(20,8) DEFAULT 0,
  net_amount      DECIMAL(20,8),
  status          VARCHAR(20) DEFAULT 'pending', -- pending | processing | completed | failed | refunded
  method          VARCHAR(50),  -- paystack | paypal | flutterwave | card | bank | crypto | alpaca
  reference       VARCHAR(255) UNIQUE,
  external_ref    VARCHAR(255),  -- PayPal txn ID, Paystack ref, etc.
  description     TEXT,
  metadata        JSONB DEFAULT '{}',
  otp_verified    BOOLEAN DEFAULT FALSE,
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ── PAYMENT CARDS ──────────────────────────────────────
CREATE TABLE payment_cards (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  provider        VARCHAR(20),  -- stripe | paystack
  token           TEXT NOT NULL,  -- provider token, never raw card data
  last4           VARCHAR(4) NOT NULL,
  brand           VARCHAR(20),  -- visa | mastercard | verve | amex
  exp_month       INT,
  exp_year        INT,
  holder_name     VARCHAR(200),
  is_default      BOOLEAN DEFAULT FALSE,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ── BANK ACCOUNTS ─────────────────────────────────────
CREATE TABLE bank_accounts (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  bank_name       VARCHAR(200) NOT NULL,
  account_number  VARCHAR(30) NOT NULL,
  account_name    VARCHAR(200) NOT NULL,
  bank_code       VARCHAR(20),
  currency        VARCHAR(10) DEFAULT 'NGN',
  country         VARCHAR(100),
  is_verified     BOOLEAN DEFAULT FALSE,
  is_default      BOOLEAN DEFAULT FALSE,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ── OTP RECORDS ────────────────────────────────────────
CREATE TABLE otp_records (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID REFERENCES users(id) ON DELETE CASCADE,
  identifier      VARCHAR(255) NOT NULL,  -- email or phone
  code            VARCHAR(10) NOT NULL,
  purpose         VARCHAR(50) NOT NULL,   -- verify_email | verify_phone | login | deposit | withdraw | 2fa
  channel         VARCHAR(10) NOT NULL,   -- email | sms
  attempts        INT DEFAULT 0,
  max_attempts    INT DEFAULT 5,
  verified        BOOLEAN DEFAULT FALSE,
  expires_at      TIMESTAMPTZ NOT NULL,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ── POSITIONS (Open Trades) ────────────────────────────
CREATE TABLE positions (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  symbol          VARCHAR(30) NOT NULL,
  market          VARCHAR(20) NOT NULL,  -- crypto | stock | forex | futures
  side            VARCHAR(10) NOT NULL,  -- long | short
  quantity        DECIMAL(20,8) NOT NULL,
  entry_price     DECIMAL(20,8) NOT NULL,
  current_price   DECIMAL(20,8),
  stop_loss       DECIMAL(20,8),
  take_profit     DECIMAL(20,8),
  strategy        VARCHAR(50),
  unrealized_pnl  DECIMAL(20,8) DEFAULT 0,
  status          VARCHAR(20) DEFAULT 'open',  -- open | closed | cancelled
  broker          VARCHAR(30),
  broker_order_id VARCHAR(255),
  opened_at       TIMESTAMPTZ DEFAULT NOW(),
  closed_at       TIMESTAMPTZ,
  close_price     DECIMAL(20,8),
  realized_pnl    DECIMAL(20,8),
  metadata        JSONB DEFAULT '{}'
);

-- ── SIGNALS ───────────────────────────────────────────
CREATE TABLE signals (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  symbol          VARCHAR(30) NOT NULL,
  market          VARCHAR(20) NOT NULL,
  direction       VARCHAR(10) NOT NULL,
  confidence      DECIMAL(5,4),
  strategy        VARCHAR(50),
  entry_price     DECIMAL(20,8),
  stop_loss       DECIMAL(20,8),
  take_profit     DECIMAL(20,8),
  timeframe       VARCHAR(10),
  status          VARCHAR(20) DEFAULT 'active',
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  expires_at      TIMESTAMPTZ
);

-- ── KYC DOCUMENTS ─────────────────────────────────────
CREATE TABLE kyc_documents (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  doc_type        VARCHAR(50) NOT NULL,  -- id_card | passport | drivers_license | utility_bill
  doc_url         TEXT NOT NULL,
  status          VARCHAR(20) DEFAULT 'pending',
  reviewer_notes  TEXT,
  submitted_at    TIMESTAMPTZ DEFAULT NOW(),
  reviewed_at     TIMESTAMPTZ
);

-- ── LIVENESS CHECKS ────────────────────────────────────
CREATE TABLE liveness_checks (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  session_id      VARCHAR(255),
  result          VARCHAR(20),  -- passed | failed | pending
  confidence      DECIMAL(5,4),
  provider        VARCHAR(50),
  metadata        JSONB DEFAULT '{}',
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ── SESSIONS ──────────────────────────────────────────
CREATE TABLE sessions (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  refresh_token   TEXT UNIQUE NOT NULL,
  ip_address      INET,
  user_agent      TEXT,
  is_active       BOOLEAN DEFAULT TRUE,
  expires_at      TIMESTAMPTZ NOT NULL,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ── AUDIT LOG ─────────────────────────────────────────
CREATE TABLE audit_logs (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID REFERENCES users(id),
  action          VARCHAR(100) NOT NULL,
  resource        VARCHAR(100),
  details         JSONB DEFAULT '{}',
  ip_address      INET,
  user_agent      TEXT,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ── NOTIFICATIONS ─────────────────────────────────────
CREATE TABLE notifications (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title           VARCHAR(200) NOT NULL,
  body            TEXT NOT NULL,
  type            VARCHAR(50),  -- trade | deposit | withdrawal | security | system
  is_read         BOOLEAN DEFAULT FALSE,
  metadata        JSONB DEFAULT '{}',
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ── INDEXES ───────────────────────────────────────────
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_phone ON users(phone);
CREATE INDEX idx_transactions_user ON transactions(user_id, created_at DESC);
CREATE INDEX idx_transactions_status ON transactions(status);
CREATE INDEX idx_transactions_reference ON transactions(reference);
CREATE INDEX idx_positions_user ON positions(user_id, status);
CREATE INDEX idx_otp_identifier ON otp_records(identifier, purpose, expires_at);
CREATE INDEX idx_signals_created ON signals(created_at DESC);
CREATE INDEX idx_notifications_user ON notifications(user_id, is_read);
CREATE INDEX idx_audit_user ON audit_logs(user_id, created_at DESC);

-- ── TRIGGERS (auto update updated_at) ─────────────────
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER wallets_updated_at BEFORE UPDATE ON wallets FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER transactions_updated_at BEFORE UPDATE ON transactions FOR EACH ROW EXECUTE FUNCTION update_updated_at();
