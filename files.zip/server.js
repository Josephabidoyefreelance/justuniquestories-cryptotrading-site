require('dotenv').config();
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const helmet = require('helmet');
const cors = require('cors');
const compression = require('compression');
const morgan = require('morgan');
const cookieParser = require('cookie-parser');
const rateLimit = require('express-rate-limit');
const logger = require('./utils/logger');

const app = express();
const server = http.createServer(app);

// ── Socket.IO for live updates ───────────────────────
const io = new Server(server, {
  cors: {
    origin: process.env.FRONTEND_URL || '*',
    methods: ['GET', 'POST'],
    credentials: true,
  },
});

// Store io instance globally
app.set('io', io);

// ── Security middleware ──────────────────────────────
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'", 'https://www.google.com', 'https://www.gstatic.com'],
      frameSrc: ["'self'", 'https://www.google.com'],
      imgSrc: ["'self'", 'data:', 'https:'],
    },
  },
}));

app.use(cors({
  origin: process.env.FRONTEND_URL || '*',
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
}));

// ── Rate limiters ────────────────────────────────────
const globalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 min
  max: 200,
  message: { success: false, error: 'Too many requests. Please wait and try again.' },
});

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  message: { success: false, error: 'Too many authentication attempts. Please wait 15 minutes.' },
});

const otpLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 min
  max: 3,
  message: { success: false, error: 'Too many OTP requests. Please wait a minute.' },
});

app.use(globalLimiter);
app.use(compression());
app.use(morgan('combined', { stream: { write: msg => logger.info(msg.trim()) } }));
app.use(cookieParser());

// Raw body for webhooks (must be before express.json)
app.use('/api/payments/webhook', express.raw({ type: 'application/json' }));

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Static files
app.use('/uploads', express.static('uploads'));

// ── Routes ───────────────────────────────────────────
app.use('/api/auth', authLimiter, require('./routes/auth'));
app.use('/api/payments', require('./routes/payments'));
app.use('/api/kyc', require('./routes/kyc'));

// Health check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    env: process.env.NODE_ENV,
    timestamp: new Date().toISOString(),
    version: '1.0.0',
  });
});

// ── Socket.IO — real-time price + notification feed ──
io.on('connection', (socket) => {
  logger.info('Client connected', { socketId: socket.id });

  socket.on('subscribe:prices', (symbols) => {
    socket.join('prices');
    logger.debug('Subscribed to prices', { symbols });
  });

  socket.on('subscribe:user', (userId) => {
    socket.join(`user:${userId}`);
  });

  socket.on('disconnect', () => {
    logger.debug('Client disconnected', { socketId: socket.id });
  });
});

// Simulate live price updates (in production, pull from Binance/Alpaca WebSocket)
const DEMO_PRICES = {
  'BTC/USDT': 67420, 'ETH/USDT': 3512, 'SOL/USDT': 182.4,
  'AAPL': 187.5, 'NVDA': 875.2, 'MSFT': 414.8,
  'EUR/USD': 1.0842, 'ES': 5832, 'GC': 2341,
};

setInterval(() => {
  Object.keys(DEMO_PRICES).forEach(sym => {
    const v = DEMO_PRICES[sym];
    DEMO_PRICES[sym] = Math.max(0.001, v + (Math.random() - 0.49) * v * 0.0008);
  });
  io.to('prices').emit('prices:update', DEMO_PRICES);
}, 2000);

// ── 404 handler ─────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ success: false, error: `Route ${req.method} ${req.path} not found` });
});

// ── Error handler ────────────────────────────────────
app.use((err, req, res, next) => {
  logger.error('Unhandled error', { message: err.message, stack: err.stack });
  res.status(500).json({ success: false, error: 'Internal server error' });
});

// ── Start server ─────────────────────────────────────
const PORT = process.env.PORT || 3001;
server.listen(PORT, () => {
  logger.info(`Just Unique Stories Trading Server running`, {
    port: PORT,
    env: process.env.NODE_ENV,
    url: `http://localhost:${PORT}`,
  });
});

module.exports = { app, server, io };
