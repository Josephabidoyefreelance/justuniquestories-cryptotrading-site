const express = require('express');
const router = express.Router();
const crypto = require('crypto');
const { v4: uuidv4 } = require('uuid');
const axios = require('axios');
const { query } = require('../config/db');
const { sendEmailOTP, sendSMSOTP, verifyOTP } = require('../services/otpService');
const { authenticate, requireEmailVerified, auditLog } = require('../middleware/auth');
const logger = require('../utils/logger');

// ── Helpers ──────────────────────────────────────────
function generateRef(prefix = 'JUS') {
  return `${prefix}-${Date.now()}-${uuidv4().substring(0, 8).toUpperCase()}`;
}

async function creditWallet(userId, amount, currency = 'USD', client = null) {
  const q = client ? client.query.bind(client) : query;
  const result = await q(
    `INSERT INTO wallets (user_id, currency, balance)
     VALUES ($1, $2, $3)
     ON CONFLICT (user_id, currency)
     DO UPDATE SET balance = wallets.balance + $3, updated_at = NOW()
     RETURNING balance`,
    [userId, currency, amount]
  );
  return result.rows[0].balance;
}

async function debitWallet(userId, amount, currency = 'USD', client = null) {
  const q = client ? client.query.bind(client) : query;
  const result = await q(
    `UPDATE wallets SET balance = balance - $1, updated_at = NOW()
     WHERE user_id = $2 AND currency = $3 AND balance >= $1
     RETURNING balance`,
    [amount, userId, currency]
  );
  if (result.rows.length === 0) throw new Error('Insufficient balance');
  return result.rows[0].balance;
}

// ══════════════════════════════════════════════════════
// POST /api/payments/deposit/request-otp
// Send OTP before allowing deposit
// ══════════════════════════════════════════════════════
router.post('/deposit/request-otp', authenticate, requireEmailVerified, async (req, res) => {
  const { channel } = req.body; // 'email' | 'sms'
  try {
    if (channel === 'sms' && !req.user.phone) {
      return res.status(400).json({ success: false, error: 'No phone number on account.' });
    }
    if (channel === 'sms') {
      await sendSMSOTP(req.user.id, req.user.phone, 'deposit');
    } else {
      await sendEmailOTP(req.user.id, req.user.email, 'deposit', req.user.first_name);
    }
    res.json({ success: true, message: `OTP sent via ${channel === 'sms' ? 'SMS' : 'email'}.` });
  } catch (err) {
    logger.error('Deposit OTP error', err);
    res.status(500).json({ success: false, error: 'Failed to send OTP.' });
  }
});

// ══════════════════════════════════════════════════════
// POST /api/payments/deposit/initialize
// Initialize deposit with chosen provider
// ══════════════════════════════════════════════════════
router.post('/deposit/initialize',
  authenticate, requireEmailVerified,
  auditLog('deposit_initialize'),
  async (req, res) => {
    const { amount, currency = 'USD', provider, otpCode, otpChannel } = req.body;

    try {
      // Verify OTP first
      const identifier = otpChannel === 'sms' ? req.user.phone : req.user.email;
      const otpResult = await verifyOTP(identifier, otpCode, 'deposit');
      if (!otpResult.success) return res.status(400).json({ success: false, error: otpResult.error });

      if (!amount || amount < 10) {
        return res.status(400).json({ success: false, error: 'Minimum deposit is $10.' });
      }

      const reference = generateRef('DEP');

      // Save pending transaction
      const txn = await query(
        `INSERT INTO transactions (user_id, type, amount, currency, status, method, reference, description)
         VALUES ($1, 'deposit', $2, $3, 'pending', $4, $5, $6) RETURNING id`,
        [req.user.id, amount, currency, provider, reference, `Deposit via ${provider}`]
      );

      let response = {};

      switch (provider) {
        case 'paystack': {
          const psRes = await axios.post(
            'https://api.paystack.co/transaction/initialize',
            {
              email: req.user.email,
              amount: Math.round(amount * 100), // Paystack uses kobo
              currency: currency === 'NGN' ? 'NGN' : 'USD',
              reference,
              callback_url: `${process.env.FRONTEND_URL}/payment/callback?ref=${reference}`,
              metadata: {
                user_id: req.user.id,
                transaction_id: txn.rows[0].id,
              },
            },
            { headers: { Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}` } }
          );
          response = {
            provider: 'paystack',
            authorizationUrl: psRes.data.data.authorization_url,
            reference,
          };
          break;
        }

        case 'paypal': {
          // Get PayPal access token
          const ppAuth = await axios.post(
            'https://api-m.paypal.com/v1/oauth2/token',
            'grant_type=client_credentials',
            {
              auth: {
                username: process.env.PAYPAL_CLIENT_ID,
                password: process.env.PAYPAL_CLIENT_SECRET,
              },
              headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            }
          );
          const ppToken = ppAuth.data.access_token;

          const ppOrder = await axios.post(
            'https://api-m.paypal.com/v2/checkout/orders',
            {
              intent: 'CAPTURE',
              purchase_units: [{
                reference_id: reference,
                amount: { currency_code: 'USD', value: amount.toFixed(2) },
                description: 'Just Unique Stories Trading Deposit',
              }],
              application_context: {
                return_url: `${process.env.FRONTEND_URL}/payment/callback?ref=${reference}&provider=paypal`,
                cancel_url: `${process.env.FRONTEND_URL}/payment/cancel`,
                brand_name: 'Just Unique Stories Trading',
              },
            },
            { headers: { Authorization: `Bearer ${ppToken}` } }
          );

          const approveLink = ppOrder.data.links.find(l => l.rel === 'approve');
          response = {
            provider: 'paypal',
            authorizationUrl: approveLink.href,
            orderId: ppOrder.data.id,
            reference,
          };

          await query(`UPDATE transactions SET external_ref = $1 WHERE reference = $2`,
            [ppOrder.data.id, reference]);
          break;
        }

        case 'flutterwave': {
          const fwRes = await axios.post(
            'https://api.flutterwave.com/v3/payments',
            {
              tx_ref: reference,
              amount,
              currency,
              redirect_url: `${process.env.FRONTEND_URL}/payment/callback?ref=${reference}&provider=flutterwave`,
              customer: { email: req.user.email, name: `${req.user.first_name} ${req.user.last_name}` },
              customizations: {
                title: 'Just Unique Stories Trading',
                description: 'Fund your trading account',
                logo: `${process.env.FRONTEND_URL}/logo.png`,
              },
            },
            { headers: { Authorization: `Bearer ${process.env.FLW_SECRET_KEY}` } }
          );
          response = {
            provider: 'flutterwave',
            authorizationUrl: fwRes.data.data.link,
            reference,
          };
          break;
        }

        case 'stripe': {
          const Stripe = require('stripe');
          const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
          const session = await stripe.checkout.sessions.create({
            payment_method_types: ['card'],
            line_items: [{
              price_data: {
                currency: currency.toLowerCase(),
                product_data: { name: 'Trading Account Deposit — Just Unique Stories' },
                unit_amount: Math.round(amount * 100),
              },
              quantity: 1,
            }],
            mode: 'payment',
            success_url: `${process.env.FRONTEND_URL}/payment/callback?ref=${reference}&provider=stripe&session_id={CHECKOUT_SESSION_ID}`,
            cancel_url: `${process.env.FRONTEND_URL}/payment/cancel`,
            client_reference_id: reference,
            customer_email: req.user.email,
          });
          response = {
            provider: 'stripe',
            authorizationUrl: session.url,
            sessionId: session.id,
            reference,
          };
          break;
        }

        case 'bank': {
          response = {
            provider: 'bank',
            reference,
            bankDetails: {
              bankName: 'GTBank Plc',
              accountName: 'Just Unique Stories Ltd',
              accountNumber: '0123456789',
              sortCode: '058',
              reference,
              note: `Please use reference ${reference} as payment narration.`,
            },
          };
          break;
        }

        default:
          return res.status(400).json({ success: false, error: 'Unknown payment provider.' });
      }

      res.json({ success: true, ...response });
    } catch (err) {
      logger.error('Deposit initialize error', err);
      res.status(500).json({ success: false, error: 'Failed to initialize deposit.' });
    }
  }
);

// ══════════════════════════════════════════════════════
// WEBHOOKS — providers call these when payment completes
// ══════════════════════════════════════════════════════

// Paystack webhook
router.post('/webhook/paystack', express.raw({ type: 'application/json' }), async (req, res) => {
  try {
    const hash = crypto
      .createHmac('sha512', process.env.PAYSTACK_WEBHOOK_SECRET)
      .update(req.body)
      .digest('hex');

    if (hash !== req.headers['x-paystack-signature']) {
      return res.status(400).send('Invalid signature');
    }

    const event = JSON.parse(req.body);
    if (event.event === 'charge.success') {
      const { reference, amount, customer, metadata } = event.data;
      const amountUSD = amount / 100;

      const txn = await query(
        `UPDATE transactions SET status = 'completed', updated_at = NOW()
         WHERE reference = $1 AND status = 'pending' RETURNING user_id, amount, currency`,
        [reference]
      );

      if (txn.rows.length > 0) {
        const { user_id, amount: txnAmount, currency } = txn.rows[0];
        await creditWallet(user_id, parseFloat(txnAmount), currency);
        await query(
          `INSERT INTO notifications (user_id, title, body, type)
           VALUES ($1, 'Deposit Successful', $2, 'deposit')`,
          [user_id, `$${txnAmount} has been added to your account via Paystack.`]
        );
        logger.info('Paystack deposit credited', { reference, userId: user_id });
      }
    }
    res.sendStatus(200);
  } catch (err) {
    logger.error('Paystack webhook error', err);
    res.sendStatus(500);
  }
});

// Flutterwave webhook
router.post('/webhook/flutterwave', async (req, res) => {
  try {
    const secretHash = process.env.FLW_WEBHOOK_SECRET;
    const signature = req.headers['verif-hash'];
    if (signature !== secretHash) return res.status(400).send('Invalid signature');

    const { event, data } = req.body;
    if (event === 'charge.completed' && data.status === 'successful') {
      const txn = await query(
        `UPDATE transactions SET status = 'completed', external_ref = $1
         WHERE reference = $2 AND status = 'pending' RETURNING user_id, amount, currency`,
        [String(data.id), data.tx_ref]
      );
      if (txn.rows.length > 0) {
        const { user_id, amount, currency } = txn.rows[0];
        await creditWallet(user_id, parseFloat(amount), currency);
        logger.info('Flutterwave deposit credited', { ref: data.tx_ref, userId: user_id });
      }
    }
    res.sendStatus(200);
  } catch (err) {
    logger.error('Flutterwave webhook error', err);
    res.sendStatus(500);
  }
});

// Stripe webhook
router.post('/webhook/stripe', express.raw({ type: 'application/json' }), async (req, res) => {
  try {
    const Stripe = require('stripe');
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
    const sig = req.headers['stripe-signature'];
    const event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);

    if (event.type === 'checkout.session.completed') {
      const session = event.data.object;
      const reference = session.client_reference_id;
      const txn = await query(
        `UPDATE transactions SET status = 'completed', external_ref = $1
         WHERE reference = $2 AND status = 'pending' RETURNING user_id, amount, currency`,
        [session.id, reference]
      );
      if (txn.rows.length > 0) {
        const { user_id, amount, currency } = txn.rows[0];
        await creditWallet(user_id, parseFloat(amount), currency);
        logger.info('Stripe deposit credited', { reference, userId: user_id });
      }
    }
    res.sendStatus(200);
  } catch (err) {
    logger.error('Stripe webhook error', err);
    res.status(400).send(`Webhook error: ${err.message}`);
  }
});

// ══════════════════════════════════════════════════════
// POST /api/payments/withdraw/request-otp
// ══════════════════════════════════════════════════════
router.post('/withdraw/request-otp', authenticate, requireEmailVerified, async (req, res) => {
  const { channel } = req.body;
  try {
    if (channel === 'sms') {
      await sendSMSOTP(req.user.id, req.user.phone, 'withdraw');
    } else {
      await sendEmailOTP(req.user.id, req.user.email, 'withdraw', req.user.first_name);
    }
    res.json({ success: true, message: `Withdrawal OTP sent via ${channel === 'sms' ? 'SMS' : 'email'}.` });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Failed to send OTP.' });
  }
});

// ══════════════════════════════════════════════════════
// POST /api/payments/withdraw
// ══════════════════════════════════════════════════════
router.post('/withdraw',
  authenticate, requireEmailVerified,
  auditLog('withdrawal'),
  async (req, res) => {
    const { amount, currency = 'USD', method, bankDetails, otpCode, otpChannel } = req.body;
    try {
      // Verify OTP
      const identifier = otpChannel === 'sms' ? req.user.phone : req.user.email;
      const otpResult = await verifyOTP(identifier, otpCode, 'withdraw');
      if (!otpResult.success) return res.status(400).json({ success: false, error: otpResult.error });

      if (!amount || amount < 20) {
        return res.status(400).json({ success: false, error: 'Minimum withdrawal is $20.' });
      }

      const fee = amount * 0.005; // 0.5% fee
      const netAmount = amount - fee;
      const reference = generateRef('WIT');

      // Debit wallet (will throw if insufficient)
      await debitWallet(req.user.id, amount, currency);

      // Record transaction
      await query(
        `INSERT INTO transactions
           (user_id, type, amount, currency, fee, net_amount, status, method, reference, description, otp_verified, metadata)
         VALUES ($1, 'withdrawal', $2, $3, $4, $5, 'processing', $6, $7, $8, true, $9)`,
        [
          req.user.id, amount, currency, fee, netAmount,
          method, reference,
          `Withdrawal to ${method}`,
          JSON.stringify(bankDetails || {}),
        ]
      );

      // Notify user
      await query(
        `INSERT INTO notifications (user_id, title, body, type)
         VALUES ($1, 'Withdrawal Processing', $2, 'withdrawal')`,
        [req.user.id, `Withdrawal of $${amount} is being processed. Reference: ${reference}`]
      );

      res.json({
        success: true,
        message: 'Withdrawal submitted. Processing within 24 hours.',
        reference,
        netAmount,
      });
    } catch (err) {
      if (err.message === 'Insufficient balance') {
        return res.status(400).json({ success: false, error: 'Insufficient wallet balance.' });
      }
      logger.error('Withdrawal error', err);
      res.status(500).json({ success: false, error: 'Withdrawal failed. Please try again.' });
    }
  }
);

// ══════════════════════════════════════════════════════
// GET /api/payments/transactions
// ══════════════════════════════════════════════════════
router.get('/transactions', authenticate, async (req, res) => {
  const { page = 1, limit = 20, type, status } = req.query;
  const offset = (page - 1) * limit;
  try {
    let whereClause = 'WHERE user_id = $1';
    const params = [req.user.id];
    if (type) { params.push(type); whereClause += ` AND type = $${params.length}`; }
    if (status) { params.push(status); whereClause += ` AND status = $${params.length}`; }

    const result = await query(
      `SELECT id, type, amount, currency, fee, net_amount, status, method, reference, description, created_at
       FROM transactions ${whereClause}
       ORDER BY created_at DESC LIMIT $${params.length + 1} OFFSET $${params.length + 2}`,
      [...params, limit, offset]
    );

    const count = await query(
      `SELECT COUNT(*) FROM transactions ${whereClause}`, params
    );

    res.json({
      success: true,
      transactions: result.rows,
      total: parseInt(count.rows[0].count),
      page: parseInt(page),
      totalPages: Math.ceil(count.rows[0].count / limit),
    });
  } catch (err) {
    logger.error('Get transactions error', err);
    res.status(500).json({ success: false, error: 'Failed to fetch transactions.' });
  }
});

// ══════════════════════════════════════════════════════
// GET /api/payments/wallet
// ══════════════════════════════════════════════════════
router.get('/wallet', authenticate, async (req, res) => {
  try {
    const wallets = await query(
      `SELECT currency, balance, locked_balance, updated_at
       FROM wallets WHERE user_id = $1`,
      [req.user.id]
    );
    res.json({ success: true, wallets: wallets.rows });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Failed to fetch wallet.' });
  }
});

module.exports = router;
