const crypto = require('crypto');
const nodemailer = require('nodemailer');
const twilio = require('twilio');
const { query } = require('../config/db');
const logger = require('../utils/logger');

const OTP_EXPIRY = parseInt(process.env.OTP_EXPIRY_MINUTES || '10');
const OTP_LENGTH = parseInt(process.env.OTP_LENGTH || '6');

// ── Email transport ──────────────────────────────────
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: parseInt(process.env.SMTP_PORT || '587'),
  secure: process.env.SMTP_SECURE === 'true',
  auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
});

// ── Twilio client ────────────────────────────────────
const twilioClient = process.env.TWILIO_ACCOUNT_SID
  ? twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN)
  : null;

// ── Generate secure OTP ──────────────────────────────
function generateOTP() {
  return crypto.randomInt(100000, 999999).toString().padStart(OTP_LENGTH, '0');
}

// ── Save OTP to database ─────────────────────────────
async function saveOTP(userId, identifier, code, purpose, channel) {
  // Invalidate existing OTPs for same purpose
  await query(
    `UPDATE otp_records SET verified = true
     WHERE identifier = $1 AND purpose = $2 AND verified = false`,
    [identifier, purpose]
  );

  const expiresAt = new Date(Date.now() + OTP_EXPIRY * 60 * 1000);
  const result = await query(
    `INSERT INTO otp_records (user_id, identifier, code, purpose, channel, expires_at)
     VALUES ($1, $2, $3, $4, $5, $6) RETURNING id`,
    [userId, identifier, code, purpose, channel, expiresAt]
  );
  return result.rows[0].id;
}

// ── Verify OTP ───────────────────────────────────────
async function verifyOTP(identifier, code, purpose) {
  const result = await query(
    `SELECT * FROM otp_records
     WHERE identifier = $1 AND purpose = $2 AND verified = false
       AND expires_at > NOW()
     ORDER BY created_at DESC LIMIT 1`,
    [identifier, purpose]
  );

  if (result.rows.length === 0) {
    return { success: false, error: 'OTP expired or not found. Please request a new one.' };
  }

  const record = result.rows[0];

  // Increment attempts
  await query(
    `UPDATE otp_records SET attempts = attempts + 1 WHERE id = $1`,
    [record.id]
  );

  if (record.attempts >= record.max_attempts) {
    await query(`UPDATE otp_records SET verified = true WHERE id = $1`, [record.id]);
    return { success: false, error: 'Too many failed attempts. Please request a new OTP.' };
  }

  if (record.code !== code) {
    const remaining = record.max_attempts - record.attempts - 1;
    return { success: false, error: `Incorrect OTP. ${remaining} attempts remaining.` };
  }

  // Mark as verified
  await query(`UPDATE otp_records SET verified = true WHERE id = $1`, [record.id]);
  return { success: true, record };
}

// ── Send email OTP ────────────────────────────────────
async function sendEmailOTP(userId, email, purpose, name = '') {
  const code = generateOTP();
  await saveOTP(userId, email, code, purpose, 'email');

  const purposeLabels = {
    verify_email: 'Email Verification',
    login: 'Login Verification',
    deposit: 'Deposit Authorization',
    withdraw: 'Withdrawal Authorization',
    '2fa': 'Two-Factor Authentication',
    reset_password: 'Password Reset',
  };

  const label = purposeLabels[purpose] || 'Verification';

  const html = `
  <!DOCTYPE html>
  <html>
  <head><meta charset="utf-8"><meta name="viewport" content="width=device-width"></head>
  <body style="margin:0;padding:0;background:#080600;font-family:Arial,sans-serif">
    <div style="max-width:580px;margin:0 auto;padding:40px 20px">
      <div style="text-align:center;margin-bottom:32px">
        <div style="font-size:28px;font-weight:900;background:linear-gradient(90deg,#F0D060,#D4A017);-webkit-background-clip:text;-webkit-text-fill-color:transparent;display:inline-block">
          Just Unique Stories
        </div>
        <div style="font-size:13px;color:#8A7A4A;margin-top:4px">AI Trading Platform</div>
      </div>
      <div style="background:#100D00;border:1px solid #3A2E00;border-radius:16px;padding:32px;text-align:center">
        <div style="font-size:18px;font-weight:700;color:#F0E6C8;margin-bottom:8px">${label}</div>
        <div style="font-size:14px;color:#8A7A4A;margin-bottom:28px">
          Hi ${name || 'there'}, use the code below to verify your ${purpose === 'deposit' ? 'deposit' : purpose === 'withdraw' ? 'withdrawal' : 'account'}.
        </div>
        <div style="background:#181200;border:2px solid #D4A017;border-radius:12px;padding:24px;margin-bottom:24px;display:inline-block;min-width:200px">
          <div style="font-size:42px;font-weight:900;color:#D4A017;letter-spacing:12px;font-family:monospace">${code}</div>
        </div>
        <div style="font-size:13px;color:#8A7A4A;margin-bottom:8px">
          This code expires in <strong style="color:#F0E6C8">${OTP_EXPIRY} minutes</strong>.
        </div>
        <div style="font-size:12px;color:#6A5A3A;margin-top:16px;padding:12px;background:#0A0800;border-radius:8px">
          If you did not request this, please ignore this email and secure your account immediately.
        </div>
      </div>
      <div style="text-align:center;margin-top:24px;font-size:11px;color:#4A3A1A">
        &copy; 2025 Just Unique Stories. All rights reserved.<br>
        This is an automated email, please do not reply.
      </div>
    </div>
  </body>
  </html>`;

  await transporter.sendMail({
    from: process.env.EMAIL_FROM,
    to: email,
    subject: `${code} — Your Just Unique Stories ${label} Code`,
    html,
  });

  logger.info(`Email OTP sent for ${purpose}`, { email: email.substring(0, 3) + '***' });
  return { success: true };
}

// ── Send SMS OTP ──────────────────────────────────────
async function sendSMSOTP(userId, phone, purpose) {
  if (!twilioClient) {
    logger.warn('Twilio not configured, cannot send SMS OTP');
    return { success: false, error: 'SMS service not configured' };
  }

  const code = generateOTP();
  await saveOTP(userId, phone, code, purpose, 'sms');

  const purposeLabels = {
    verify_phone: 'Phone Verification',
    login: 'Login',
    deposit: 'Deposit Authorization',
    withdraw: 'Withdrawal Authorization',
  };

  const label = purposeLabels[purpose] || 'Verification';

  await twilioClient.messages.create({
    body: `Just Unique Stories: Your ${label} code is ${code}. Valid for ${OTP_EXPIRY} minutes. Do not share this code.`,
    from: process.env.TWILIO_PHONE,
    to: phone,
  });

  logger.info(`SMS OTP sent for ${purpose}`, { phone: phone.substring(0, 4) + '***' });
  return { success: true };
}

module.exports = { sendEmailOTP, sendSMSOTP, verifyOTP, generateOTP };
