const jwt = require('jsonwebtoken');
const { query } = require('../config/db');
const logger = require('../utils/logger');

const authenticate = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    const token = authHeader?.startsWith('Bearer ') ? authHeader.slice(7) : null;

    if (!token) {
      return res.status(401).json({ success: false, error: 'Access token required' });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    const result = await query(
      `SELECT id, email, first_name, last_name, role, status, email_verified,
              kyc_status, two_fa_enabled, trading_mode, currency
       FROM users WHERE id = $1`,
      [decoded.userId]
    );

    if (result.rows.length === 0) {
      return res.status(401).json({ success: false, error: 'User not found' });
    }

    const user = result.rows[0];

    if (user.status === 'banned') {
      return res.status(403).json({ success: false, error: 'Account suspended. Contact support.' });
    }

    req.user = user;
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ success: false, error: 'Token expired', code: 'TOKEN_EXPIRED' });
    }
    if (err.name === 'JsonWebTokenError') {
      return res.status(401).json({ success: false, error: 'Invalid token' });
    }
    logger.error('Auth middleware error', err);
    return res.status(500).json({ success: false, error: 'Authentication error' });
  }
};

const requireEmailVerified = (req, res, next) => {
  if (!req.user.email_verified) {
    return res.status(403).json({
      success: false,
      error: 'Please verify your email address first.',
      code: 'EMAIL_NOT_VERIFIED',
    });
  }
  next();
};

const requireKYC = (req, res, next) => {
  if (req.user.kyc_status !== 'verified') {
    return res.status(403).json({
      success: false,
      error: 'KYC verification required for this action.',
      code: 'KYC_REQUIRED',
    });
  }
  next();
};

const requireAdmin = (req, res, next) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ success: false, error: 'Admin access required' });
  }
  next();
};

const auditLog = (action) => async (req, res, next) => {
  try {
    await query(
      `INSERT INTO audit_logs (user_id, action, resource, details, ip_address, user_agent)
       VALUES ($1, $2, $3, $4, $5, $6)`,
      [
        req.user?.id || null,
        action,
        req.path,
        JSON.stringify({ body: req.body, params: req.params }),
        req.ip,
        req.headers['user-agent'],
      ]
    );
  } catch (err) {
    logger.error('Audit log error', err);
  }
  next();
};

module.exports = { authenticate, requireEmailVerified, requireKYC, requireAdmin, auditLog };
