# Just Unique Stories — Full Deployment Guide
## From zero to live production

---

## What you now have

```
justuniquestories/
├── backend/
│   ├── src/
│   │   ├── server.js          ← Main entry point + Socket.IO live prices
│   │   ├── routes/
│   │   │   ├── auth.js        ← Register, Login, OTP, Google OAuth, 2FA
│   │   │   ├── payments.js    ← Paystack, PayPal, Flutterwave, Stripe, Bank + Webhooks
│   │   │   └── kyc.js         ← KYC documents + Liveness check (AWS Rekognition)
│   │   ├── services/
│   │   │   └── otpService.js  ← Email + SMS OTP
│   │   ├── middleware/
│   │   │   └── auth.js        ← JWT auth, role checks, audit logging
│   │   ├── config/
│   │   │   └── db.js          ← PostgreSQL pool
│   │   └── utils/
│   │       ├── schema.sql     ← Full database schema
│   │       └── logger.js      ← Winston logger
│   ├── .env.example           ← All environment variables needed
│   └── package.json
└── frontend/
    └── public/
        └── (your trading_joseph.html goes here)
```

---

## Step 1 — Set up a server

**Cheapest options:**
- **Railway.app** (easiest, $5/mo) — https://railway.app
- **Render.com** (free tier available) — https://render.com
- **DigitalOcean** ($6/mo droplet) — https://digitalocean.com
- **VPS (Contabo/Hetzner)** — cheapest for Nigeria ($4/mo)

For Nigeria with low latency, use **DigitalOcean Frankfurt** or **Hetzner** (both have good Africa routing).

---

## Step 2 — Set up PostgreSQL

**Option A — Railway (easiest):**
1. Go to railway.app → New Project → Add PostgreSQL
2. Copy the DATABASE_URL into your .env

**Option B — Supabase (free):**
1. Go to supabase.com → New Project
2. Get connection string from Settings → Database

**Option C — DigitalOcean Managed DB:**
1. Create → Databases → PostgreSQL
2. $15/mo but fully managed

After creating DB, run the schema:
```bash
psql $DATABASE_URL -f src/utils/schema.sql
```

---

## Step 3 — Get all your API keys

### Paystack (Nigeria payments)
1. Go to https://dashboard.paystack.com
2. Settings → API Keys → Copy Secret Key
3. Set up webhook: Settings → Webhooks → https://yourdomain.com/api/payments/webhook/paystack

### PayPal
1. Go to https://developer.paypal.com
2. Dashboard → Apps → Create App
3. Copy Client ID and Secret
4. Set webhook in App Settings → https://yourdomain.com/api/payments/webhook/paypal

### Flutterwave
1. Go to https://dashboard.flutterwave.com
2. Settings → API Keys → Copy keys
3. Set webhook: Settings → Webhooks → https://yourdomain.com/api/payments/webhook/flutterwave

### Stripe (international cards)
1. Go to https://dashboard.stripe.com
2. Developers → API Keys → Copy keys
3. Set webhook: Developers → Webhooks → Add endpoint

### Twilio (SMS OTP)
1. Go to https://console.twilio.com
2. Buy a phone number (from $1/mo)
3. Copy Account SID, Auth Token, Phone Number

### Email (Gmail App Password)
1. Google Account → Security → 2-Step Verification → App passwords
2. Generate password for "Mail"
3. Use as SMTP_PASS

### Google OAuth
1. https://console.cloud.google.com
2. APIs & Services → Credentials → Create OAuth 2.0 Client
3. Add authorized redirect URI: https://yourdomain.com/api/auth/google/callback

### reCAPTCHA v3
1. https://www.google.com/recaptcha/admin
2. Register site → v3 → Copy Site Key and Secret Key

### AWS Rekognition (Liveness check — optional)
1. https://aws.amazon.com → IAM → Create user with Rekognition permissions
2. Copy Access Key and Secret

---

## Step 4 — Deploy backend

```bash
# Clone / upload your backend files to server
cd justuniquestories/backend

# Install dependencies
npm install

# Copy and fill environment file
cp .env.example .env
nano .env   # Fill in all values

# Run database schema
psql $DB_URL -f src/utils/schema.sql

# Start with PM2 (keeps it running)
npm install -g pm2
pm2 start src/server.js --name "jus-trading"
pm2 startup
pm2 save
```

---

## Step 5 — Deploy frontend

Update `trading_joseph.html` — change the API_URL constant:
```javascript
const API_URL = 'https://api.yourdomain.com';   // your backend URL
const SOCKET_URL = 'https://api.yourdomain.com'; // same
```

Then host the HTML on:
- **Netlify** (free): drag and drop the HTML file
- **Vercel** (free): `npx vercel`
- **Cloudflare Pages** (free): push to GitHub

---

## Step 6 — Domain and SSL

1. Buy domain from **Namecheap** (~$10/yr)
2. Point DNS to your server IP
3. Install SSL:
```bash
sudo apt install certbot nginx
sudo certbot --nginx -d yourdomain.com -d api.yourdomain.com
```

Or use **Cloudflare** (free SSL, just proxy your domain).

---

## Step 7 — Set up Nginx (reverse proxy)

```nginx
server {
    listen 443 ssl;
    server_name api.yourdomain.com;

    location / {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_cache_bypass $http_upgrade;
    }
}
```

---

## Security checklist before going live

- [ ] All .env values filled (no placeholders)
- [ ] DB_SSL=true for production database
- [ ] NODE_ENV=production
- [ ] JWT_SECRET is at least 64 random characters
- [ ] Webhook secrets set for all payment providers
- [ ] reCAPTCHA enabled
- [ ] Email sending tested
- [ ] SMS OTP tested
- [ ] Rate limiting verified
- [ ] CORS restricted to your domain only (not *)
- [ ] SSL certificate installed
- [ ] Firewall: only ports 80, 443, 22 open
- [ ] Regular database backups scheduled

---

## How payments actually credit accounts (the full flow)

```
User clicks "Deposit $100 via Paystack"
    → Frontend sends POST /api/payments/deposit/request-otp
    → User receives OTP on email/phone
    → User enters OTP
    → Frontend sends POST /api/payments/deposit/initialize
    → Backend creates pending transaction in DB
    → Backend calls Paystack API → gets payment URL
    → User redirected to Paystack checkout
    → User pays on Paystack
    → Paystack sends webhook to POST /api/payments/webhook/paystack
    → Backend verifies webhook signature
    → Backend marks transaction as 'completed'
    → Backend calls creditWallet() → adds $100 to user's wallet in DB
    → Socket.IO emits notification to user's browser
    → User sees balance updated in real time ✓
```

---

## Estimated monthly costs

| Service | Cost |
|---------|------|
| VPS (DigitalOcean) | $6/mo |
| PostgreSQL (Supabase free) | $0 |
| Email (Gmail) | $0 |
| Twilio SMS (per OTP ~$0.0075) | ~$5/mo |
| Domain | ~$0.83/mo |
| SSL (Certbot) | $0 |
| **Total** | **~$12/mo** |

Payment providers charge per transaction:
- Paystack: 1.5% + ₦100 (capped at ₦2,000)
- Flutterwave: 1.4% international, 1.4% local
- Stripe: 2.9% + $0.30
- PayPal: 3.49% + $0.49
