const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const axios = require('axios');
const { query } = require('../config/db');
const { sendEmailOTP, sendSMSOTP, verifyOTP } = require('../services/otpService');
const { authenticate } = require('../middleware/auth');
const logger = require('../utils/logger');

// ── Token helpers ────────────────────────────────────
function generateTokens(userId, email, role) {
  const accessToken = jwt.sign(
    { userId, email, role },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '15m' }
  );
  const refreshToken = jwt.sign(
    { userId },
    process.env.JWT_REFRESH_SECRET,
    { expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '7d' }
  );
  return { accessToken, refreshToken };
}

async function saveSession(userId, refreshToken, req) {
  const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
  await query(
    `INSERT INTO sessions (user_id, refresh_token, ip_address, user_agent, expires_at)
     VALUES ($1, $2, $3, $4, $5)
     ON CONFLICT (refresh_token) DO NOTHING`,
    [userId, refreshToken, req.ip, req.headers['user-agent'], expiresAt]
  );
}

// ── Verify reCAPTCHA ────────────────────────────────
async function verifyCaptcha(token) {
  if (!process.env.RECAPTCHA_SECRET_KEY || process.env.NODE_ENV === 'development') return true;
  try {
    const res = await axios.post(
      `https://www.google.com/recaptcha/api/siteverify`,
      null,
      { params: { secret: process.env.RECAPTCHA_SECRET_KEY, response: token } }
    );
    return res.data.success && res.data.score >= 0.5;
  } catch {
    return false;
  }
}

// ══════════════════════════════════════════════════════
// POST /api/auth/register
// ══════════════════════════════════════════════════════
router.post('/register', async (req, res) => {
  const { firstName, lastName, email, phone, password, country, captchaToken } = req.body;

  try {
    // reCAPTCHA
    const captchaOk = await verifyCaptcha(captchaToken);
    if (!captchaOk) return res.status(400).json({ success: false, error: 'CAPTCHA verification failed.' });

    // Validate
    if (!firstName || !lastName || !email || !password) {
      return res.status(400).json({ success: false, error: 'All fields required.' });
    }
    if (password.length < 8) {
      return res.status(400).json({ success: false, error: 'Password must be at least 8 characters.' });
    }

    // Check existing
    const existing = await query('SELECT id FROM users WHERE email = $1', [email.toLowerCase()]);
    if (existing.rows.length > 0) {
      return res.status(409).json({ success: false, error: 'An account with this email already exists.' });
    }

    // Hash password
    const passwordHash = await bcrypt.hash(password, 12);

    // Create user
    const result = await query(
      `INSERT INTO users (email, phone, password_hash, first_name, last_name, country, provider)
       VALUES ($1, $2, $3, $4, $5, $6, 'email') RETURNING id, email, first_name, last_name`,
      [email.toLowerCase(), phone || null, passwordHash, firstName, lastName, country || null]
    );
    const user = result.rows[0];

    // Create USD wallet
    await query(
      `INSERT INTO wallets (user_id, currency, balance) VALUES ($1, 'USD', 0)`,
      [user.id]
    );

    // Send email verification OTP
    await sendEmailOTP(user.id, email, 'verify_email', firstName);

    // Optionally send phone OTP
    if (phone) await sendSMSOTP(user.id, phone, 'verify_phone');

    logger.info('New user registered', { userId: user.id, email: email.substring(0, 3) + '***' });

    res.status(201).json({
      success: true,
      message: 'Account created. Check your email for verification code.',
      userId: user.id,
      requiresEmailVerification: true,
    });
  } catch (err) {
    logger.error('Register error', err);
    res.status(500).json({ success: false, error: 'Registration failed. Please try again.' });
  }
});

// ══════════════════════════════════════════════════════
// POST /api/auth/verify-email
// ══════════════════════════════════════════════════════
router.post('/verify-email', async (req, res) => {
  const { email, code } = req.body;
  try {
    const result = await verifyOTP(email, code, 'verify_email');
    if (!result.success) return res.status(400).json({ success: false, error: result.error });

    await query(
      `UPDATE users SET email_verified = true WHERE email = $1`,
      [email.toLowerCase()]
    );

    res.json({ success: true, message: 'Email verified successfully. You can now log in.' });
  } catch (err) {
    logger.error('Email verify error', err);
    res.status(500).json({ success: false, error: 'Verification failed.' });
  }
});

// ══════════════════════════════════════════════════════
// POST /api/auth/login  — Step 1: credentials
// ══════════════════════════════════════════════════════
router.post('/login', async (req, res) => {
  const { email, password, captchaToken } = req.body;
  try {
    const captchaOk = await verifyCaptcha(captchaToken);
    if (!captchaOk) return res.status(400).json({ success: false, error: 'CAPTCHA verification failed.' });

    if (!email || !password) {
      return res.status(400).json({ success: false, error: 'Email and password required.' });
    }

    const result = await query(
      `SELECT * FROM users WHERE email = $1 AND provider = 'email'`,
      [email.toLowerCase()]
    );

    if (result.rows.length === 0) {
      return res.status(401).json({ success: false, error: 'Invalid email or password.' });
    }

    const user = result.rows[0];

    // Check lockout
    if (user.locked_until && new Date(user.locked_until) > new Date()) {
      const mins = Math.ceil((new Date(user.locked_until) - new Date()) / 60000);
      return res.status(429).json({
        success: false,
        error: `Account locked. Try again in ${mins} minute(s).`,
      });
    }

    // Check password
    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid) {
      const failCount = user.failed_login_count + 1;
      const lockUntil = failCount >= 5 ? new Date(Date.now() + 15 * 60 * 1000) : null;
      await query(
        `UPDATE users SET failed_login_count = $1, locked_until = $2 WHERE id = $3`,
        [failCount, lockUntil, user.id]
      );
      const remaining = Math.max(0, 5 - failCount);
      return res.status(401).json({
        success: false,
        error: remaining > 0
          ? `Invalid password. ${remaining} attempt(s) remaining.`
          : 'Account locked for 15 minutes due to too many failed attempts.',
      });
    }

    // Reset failed count
    await query(
      `UPDATE users SET failed_login_count = 0, locked_until = NULL, last_login = NOW(), last_ip = $1 WHERE id = $2`,
      [req.ip, user.id]
    );

    // Check email verified
    if (!user.email_verified) {
      await sendEmailOTP(user.id, email, 'verify_email', user.first_name);
      return res.status(403).json({
        success: false,
        error: 'Email not verified. A new verification code has been sent.',
        code: 'EMAIL_NOT_VERIFIED',
        userId: user.id,
      });
    }

    // 2FA if enabled
    if (user.two_fa_enabled) {
      return res.json({
        success: true,
        requires2FA: true,
        userId: user.id,
        message: 'Enter your 2FA code.',
      });
    }

    // Send login OTP (always require for security)
    await sendEmailOTP(user.id, email, 'login', user.first_name);

    res.json({
      success: true,
      requiresOTP: true,
      userId: user.id,
      otpChannel: user.phone ? 'choice' : 'email',
      message: 'Verification code sent to your email.',
    });
  } catch (err) {
    logger.error('Login error', err);
    res.status(500).json({ success: false, error: 'Login failed. Please try again.' });
  }
});

// ══════════════════════════════════════════════════════
// POST /api/auth/login/send-otp  — resend or switch channel
// ══════════════════════════════════════════════════════
router.post('/login/send-otp', async (req, res) => {
  const { userId, channel } = req.body; // channel: 'email' | 'sms'
  try {
    const result = await query('SELECT * FROM users WHERE id = $1', [userId]);
    if (result.rows.length === 0) return res.status(404).json({ success: false, error: 'User not found.' });
    const user = result.rows[0];

    if (channel === 'sms') {
      if (!user.phone) return res.status(400).json({ success: false, error: 'No phone number on account.' });
      await sendSMSOTP(user.id, user.phone, 'login');
      res.json({ success: true, message: 'OTP sent via SMS.' });
    } else {
      await sendEmailOTP(user.id, user.email, 'login', user.first_name);
      res.json({ success: true, message: 'OTP sent to email.' });
    }
  } catch (err) {
    logger.error('Send OTP error', err);
    res.status(500).json({ success: false, error: 'Failed to send OTP.' });
  }
});

// ══════════════════════════════════════════════════════
// POST /api/auth/login/verify-otp  — Step 2: OTP
// ══════════════════════════════════════════════════════
router.post('/login/verify-otp', async (req, res) => {
  const { userId, code, channel } = req.body;
  try {
    const result = await query('SELECT * FROM users WHERE id = $1', [userId]);
    if (result.rows.length === 0) return res.status(404).json({ success: false, error: 'User not found.' });
    const user = result.rows[0];

    const identifier = channel === 'sms' ? user.phone : user.email;
    const otpResult = await verifyOTP(identifier, code, 'login');
    if (!otpResult.success) return res.status(400).json({ success: false, error: otpResult.error });

    const { accessToken, refreshToken } = generateTokens(user.id, user.email, user.role);
    await saveSession(user.id, refreshToken, req);

    res.json({
      success: true,
      accessToken,
      refreshToken,
      user: {
        id: user.id,
        email: user.email,
        firstName: user.first_name,
        lastName: user.last_name,
        role: user.role,
        kycStatus: user.kyc_status,
        tradingMode: user.trading_mode,
        currency: user.currency,
      },
    });
  } catch (err) {
    logger.error('Verify OTP error', err);
    res.status(500).json({ success: false, error: 'OTP verification failed.' });
  }
});

// ══════════════════════════════════════════════════════
// POST /api/auth/refresh
// ══════════════════════════════════════════════════════
router.post('/refresh', async (req, res) => {
  const { refreshToken } = req.body;
  try {
    const decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET);
    const session = await query(
      `SELECT s.*, u.email, u.role FROM sessions s
       JOIN users u ON u.id = s.user_id
       WHERE s.refresh_token = $1 AND s.is_active = true AND s.expires_at > NOW()`,
      [refreshToken]
    );
    if (session.rows.length === 0) {
      return res.status(401).json({ success: false, error: 'Invalid or expired session.' });
    }
    const { accessToken, refreshToken: newRefresh } = generateTokens(
      decoded.userId, session.rows[0].email, session.rows[0].role
    );
    await query(`UPDATE sessions SET refresh_token = $1, expires_at = $2 WHERE refresh_token = $3`,
      [newRefresh, new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), refreshToken]);
    res.json({ success: true, accessToken, refreshToken: newRefresh });
  } catch (err) {
    res.status(401).json({ success: false, error: 'Session expired. Please log in again.' });
  }
});

// ══════════════════════════════════════════════════════
// POST /api/auth/logout
// ══════════════════════════════════════════════════════
router.post('/logout', authenticate, async (req, res) => {
  const { refreshToken } = req.body;
  try {
    await query(`UPDATE sessions SET is_active = false WHERE refresh_token = $1`, [refreshToken]);
    res.json({ success: true, message: 'Logged out successfully.' });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Logout failed.' });
  }
});

// ══════════════════════════════════════════════════════
// GET /api/auth/google  — Google OAuth
// ══════════════════════════════════════════════════════
router.get('/google', (req, res) => {
  const params = new URLSearchParams({
    client_id: process.env.GOOGLE_CLIENT_ID,
    redirect_uri: process.env.GOOGLE_CALLBACK_URL,
    response_type: 'code',
    scope: 'openid email profile',
    access_type: 'offline',
    state: uuidv4(),
  });
  res.redirect(`https://accounts.google.com/o/oauth2/v2/auth?${params}`);
});

router.get('/google/callback', async (req, res) => {
  const { code } = req.query;
  try {
    // Exchange code for tokens
    const tokenRes = await axios.post('https://oauth2.googleapis.com/token', {
      code, client_id: process.env.GOOGLE_CLIENT_ID,
      client_secret: process.env.GOOGLE_CLIENT_SECRET,
      redirect_uri: process.env.GOOGLE_CALLBACK_URL,
      grant_type: 'authorization_code',
    });
    const { access_token } = tokenRes.data;

    // Get user info
    const userRes = await axios.get('https://www.googleapis.com/oauth2/v3/userinfo',
      { headers: { Authorization: `Bearer ${access_token}` } }
    );
    const { sub: googleId, email, given_name: firstName, family_name: lastName, picture } = userRes.data;

    // Upsert user
    let user = await query('SELECT * FROM users WHERE google_id = $1 OR email = $2', [googleId, email]);

    if (user.rows.length === 0) {
      const result = await query(
        `INSERT INTO users (email, first_name, last_name, google_id, provider, email_verified, avatar_url)
         VALUES ($1, $2, $3, $4, 'google', true, $5) RETURNING *`,
        [email, firstName, lastName || '', googleId, picture]
      );
      user = result;
      await query(`INSERT INTO wallets (user_id, currency, balance) VALUES ($1, 'USD', 0)`, [result.rows[0].id]);
    } else if (!user.rows[0].google_id) {
      await query(`UPDATE users SET google_id = $1, avatar_url = $2 WHERE email = $3`, [googleId, picture, email]);
    }

    const u = user.rows[0];
    const { accessToken, refreshToken } = generateTokens(u.id, u.email, u.role);
    await saveSession(u.id, refreshToken, req);

    // Redirect to frontend with tokens
    res.redirect(`${process.env.FRONTEND_URL}/auth/callback?token=${accessToken}&refresh=${refreshToken}`);
  } catch (err) {
    logger.error('Google OAuth error', err);
    res.redirect(`${process.env.FRONTEND_URL}/login?error=google_failed`);
  }
});

// ══════════════════════════════════════════════════════
// POST /api/auth/forgot-password
// ══════════════════════════════════════════════════════
router.post('/forgot-password', async (req, res) => {
  const { email } = req.body;
  try {
    const result = await query('SELECT * FROM users WHERE email = $1', [email.toLowerCase()]);
    // Always return success to prevent email enumeration
    if (result.rows.length > 0) {
      const user = result.rows[0];
      await sendEmailOTP(user.id, email, 'reset_password', user.first_name);
    }
    res.json({ success: true, message: 'If that email exists, a reset code has been sent.' });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Failed to send reset email.' });
  }
});

// ══════════════════════════════════════════════════════
// POST /api/auth/reset-password
// ══════════════════════════════════════════════════════
router.post('/reset-password', async (req, res) => {
  const { email, code, newPassword } = req.body;
  try {
    const otpResult = await verifyOTP(email, code, 'reset_password');
    if (!otpResult.success) return res.status(400).json({ success: false, error: otpResult.error });

    if (!newPassword || newPassword.length < 8) {
      return res.status(400).json({ success: false, error: 'Password must be at least 8 characters.' });
    }

    const hash = await bcrypt.hash(newPassword, 12);
    await query(`UPDATE users SET password_hash = $1, failed_login_count = 0, locked_until = NULL WHERE email = $2`,
      [hash, email.toLowerCase()]);

    // Invalidate all sessions
    await query(`UPDATE sessions SET is_active = false WHERE user_id = (SELECT id FROM users WHERE email = $1)`,
      [email.toLowerCase()]);

    res.json({ success: true, message: 'Password reset successful. Please log in.' });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Password reset failed.' });
  }
});

// ══════════════════════════════════════════════════════
// GET /api/auth/me
// ══════════════════════════════════════════════════════
router.get('/me', authenticate, async (req, res) => {
  try {
    const wallet = await query(
      `SELECT currency, balance FROM wallets WHERE user_id = $1`,
      [req.user.id]
    );
    res.json({
      success: true,
      user: {
        ...req.user,
        wallets: wallet.rows,
      },
    });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Failed to fetch profile.' });
  }
});

module.exports = router;
